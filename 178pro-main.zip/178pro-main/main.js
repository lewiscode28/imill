let latitude = 22.7868542, longitude = 88.3643296;

// Initializing Mapbox




//Add Mapbox Geocoder





var img1 = document.querySelector("#amber")

// Create a Amber Palace, Jaipur Marker and add it to the map.

// Create a  Gateway of India, Mumbai Marker and add it to the map.

// Create a India Gate Marker and add it to the map.


// Create a Lotus Temple, Delhi Marker and add it to the map.


//Create a Victoria Memorial, Kolkata Marker and add it to the map.
